import React from 'react'
import Hero from "./Hero"

const Contact = () => {
  return (
    <div>
      <Hero />
    </div>
  )
}

export default Contact
