import React from 'react'
import Hero from "./BlogDetailsHero"

const BlogDettailsPage = () => {
  return (
    <div>
      <Hero />
    </div>
  )
}

export default BlogDettailsPage
