import React from 'react'
import Hero from './Hero'
const BlogPage = () => {
  return (
    <div>
      <Hero />
      
    </div>
  )
}

export default BlogPage
