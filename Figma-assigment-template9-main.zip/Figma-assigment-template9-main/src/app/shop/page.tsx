import React from 'react'
import Hero from "./Hero"

const Shop = () => {
  return (
    <div>
      <Hero />
    </div>
  )
}

export default Shop
