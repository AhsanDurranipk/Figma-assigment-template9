import React from 'react'
import Hero from "./Hero"

const ShopDettails = () => {
  return (
    <div>
      <Hero />
      
    </div>
  )
}

export default ShopDettails
