import React from 'react'
import Hero from "./Hero"

const ShopList = () => {
  return (
    <div>
      <Hero />
      
    </div>
  )
}

export default ShopList
