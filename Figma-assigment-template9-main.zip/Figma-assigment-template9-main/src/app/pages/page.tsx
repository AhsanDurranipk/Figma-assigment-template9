import React from 'react'
import Hero from "./Hero"

const Pages = () => {
  return (
    <div>
      <Hero />
    </div>
  )
}

export default Pages
